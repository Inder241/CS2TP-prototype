using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//to make the variables show up on the unity inspector 
[System.Serializable]

public class Champ
{
    public string nameChamp;
    public GameObject prefabChamp;
    public int champNumber;
}
