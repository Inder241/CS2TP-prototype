using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;
using Photon.Realtime;
using TMPro;
using UnityEngine.SceneManagement;

public class CreateAndJoinRooms : MonoBehaviourPunCallbacks
{
    public InputField createInput;
    public InputField joinInput;
    public InputField playerUsername;
    public TextMeshProUGUI titleName;
    //store each player into this list when they join the lobby
    List<Player> listPlayer = new List<Player>();

    public void Start()
    {
        if (!PlayerPrefs.HasKey("PlayerName"))
        {
            Debug.Log("Value not set for username.");
        }
        else
        {
            string player_username = PlayerPrefs.GetString("PlayerName");
            playerUsername.text = player_username;
        }
    }
    public void OnConfirm()
    {
        //set the title to the username 
        string player_name = playerUsername.text;
        PhotonNetwork.NickName = player_name;
        PlayerPrefs.SetString("PlayerName", player_name);
        titleName.text = PlayerPrefs.GetString("PlayerName");
    }
    public void OnCreate()
    {
        if (!PlayerPrefs.HasKey("PlayerName") && createInput.text.Length >= 1)
        {
            Debug.Log("Value not set for username.");
        }
        else
        {
            PhotonNetwork.CreateRoom(createInput.text, new RoomOptions() { MaxPlayers = 2, BroadcastPropsChangeToAll = true });
        }
    }
    public void OnJoin()
    {
        if (!PlayerPrefs.HasKey("PlayerName"))
        {
            Debug.Log("Value not set for username.");
        }
        else
        {
            PhotonNetwork.JoinRoom(joinInput.text);
        }
    }
    public override void OnJoinedRoom()
    {
        PhotonNetwork.LoadLevel("PreBattleLobby");
    }
    public void OnMainMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }
}
