using System.Collections;
using System.Collections.Generic;
using System.Web;
using UnityEngine;
using UnityEngine.UI;
using PlayFab;
using PlayFab.ClientModels;
using TMPro;
using Photon.Pun;
using UnityEngine.SceneManagement;
using PlayFab.Json;
public class PlayFabLobbyManager : MonoBehaviour
{
    [SerializeField] GameObject loginPannel, registrationPannel, photonConnectPannel;
    public Text usernameRegistration, userEmailRegistration, userPasswordRegistration, confirmUserePasswordRegistration, usernameLogin, userPasswordLogin, errorSignUp, errorLogin, currentUsername;
    public TextMeshProUGUI buttonText;
    public GameObject leaderBoardPannel;
    public Text nameInput;
    string encryptedPassword;
    public GameObject rowPrefab;
    public Transform rowsParent;
    bool setActive = true;
    public GameObject photonNameInput;
    public TextMeshProUGUI photonWelcomeText;

    public void RegistrationPannelActive()
    {
        registrationPannel.SetActive(true);
        loginPannel.SetActive(false);
        //set the error to null sp no meesages are displayed 
        errorSignUp.text = "";
        errorLogin.text = "";
        FindObjectOfType<AudioManager>().Play("Button_Pressed_Sound");
    }
    public void LoginPannelActive()
    {
        registrationPannel.SetActive(false);
        loginPannel.SetActive(true);
        //set the error to null sp no meesages are displayed 
        errorSignUp.text = "";
        errorLogin.text = "";
        FindObjectOfType<AudioManager>().Play("Button_Pressed_Sound");
    }
    //MAKE AN ENCRYPTION FUNCTION 
    string EncryptInfo(string info)
    {
        System.Security.Cryptography.MD5CryptoServiceProvider encryptedData = new System.Security.Cryptography.MD5CryptoServiceProvider();
        byte[] byteStream = System.Text.Encoding.UTF8.GetBytes(info);
        byteStream = encryptedData.ComputeHash(byteStream);
        System.Text.StringBuilder stringBuilder = new System.Text.StringBuilder();
        foreach (byte b in byteStream)
        {
            stringBuilder.Append(b.ToString("x2").ToLower());
        }
        return stringBuilder.ToString();
    }
    public void SignUp()
    {
        if (confirmUserePasswordRegistration.text == userPasswordRegistration.text)
        {
            var resgisterRequest = new RegisterPlayFabUserRequest
            {
                Email = userEmailRegistration.text,
                Password = EncryptInfo(confirmUserePasswordRegistration.text),
                Username = usernameRegistration.text
            };
            PlayFabClientAPI.RegisterPlayFabUser(resgisterRequest, RegisterSuccess, RegisterError);
        }
        else
        {
            errorSignUp.text = "Error: Password does not match!";
        }
        FindObjectOfType<AudioManager>().Play("Button_Pressed_Sound");
    }
    public void RegisterSuccess(RegisterPlayFabUserResult result)
    {
        errorSignUp.text = "";
        errorLogin.text = "";
        Debug.LogError("Account created!");
        LoginPannelActive();
    }
    public void LoginSuccess(LoginResult result)
    {
        errorSignUp.text = "";
        errorLogin.text = "";
        //get the display name of the logged in player
        string name = null;
        if (result.InfoResultPayload.PlayerProfile != null)
        {
            name = result.InfoResultPayload.PlayerProfile.DisplayName;
            PhotonNetwork.NickName = result.InfoResultPayload.PlayerProfile.DisplayName;
            Debug.LogError(PhotonNetwork.NickName);
        }
        StartGame();
    }
    public void RegisterError(PlayFabError error)
    {
        errorSignUp.text = error.GenerateErrorReport();
    }
    public void OnSubmitButton()
    {
        var request = new UpdateUserTitleDisplayNameRequest
        {
            DisplayName = nameInput.text
        };
        PlayFabClientAPI.UpdateUserTitleDisplayName(request, OnDisplayNameUpdate, LoginError);
    }
    void OnDisplayNameUpdate(UpdateUserTitleDisplayNameResult result)
    {
        Debug.Log("Updated display name!");
    }
    public void LoginError(PlayFabError error)
    {
        buttonText.text = "Ok";
        errorLogin.text = error.GenerateErrorReport();
    }
    void StartGame()
    {
        registrationPannel.SetActive(false);
        loginPannel.SetActive(false);
        photonConnectPannel.SetActive(true);
        if (PhotonNetwork.NickName != null)
        {
            photonNameInput.SetActive(false);
            photonWelcomeText.text = "You have alredy set a username for your profile, please connect to the photon server.";
        }
        //start the game or create a new hub to create the login
        currentUsername.text = usernameLogin.text;
    }
    public void Login()
    {
        var request = new LoginWithEmailAddressRequest
        {
            Email = usernameLogin.text,
            Password = EncryptInfo(userPasswordLogin.text),
            InfoRequestParameters = new GetPlayerCombinedInfoRequestParams
            {
                GetPlayerProfile = true,
            }
        };
        PlayFabClientAPI.LoginWithEmailAddress(request, LoginSuccess, LoginError);
        buttonText.text = "Connecting. . .";
        Debug.LogError("Encrypted password: " + EncryptInfo(userPasswordLogin.text));
        FindObjectOfType<AudioManager>().Play("Button_Pressed_Sound");
    }
    public void SendDataLeaderBoard(int score)
    {
        PlayFabClientAPI.ExecuteCloudScript(new ExecuteCloudScriptRequest()
        {
            FunctionName = "Send_Hero_Fate_Leaderbaord",
            FunctionParameter = new { scoreSend = score },
            GeneratePlayStreamEvent = true,
        }, OnCloudUpdateStats, OnErrorShared);

    }

    private static void OnCloudUpdateStats(ExecuteCloudScriptResult result)
    {
        Debug.Log(PlayFab.PluginManager.GetPlugin<ISerializerPlugin>(PluginContract.PlayFab_Serializer));
        JsonObject jsonResult = (JsonObject)result.FunctionResult;
        object messageValue;
        jsonResult.TryGetValue("messageValue", out messageValue);
        Debug.Log((string)messageValue);
    }

    private static void OnErrorShared(PlayFabError error)
    {
        Debug.Log(error.GenerateErrorReport());
    }
    void OnLeaderBoardError(PlayFabError error)
    {
        Debug.LogError(error.GenerateErrorReport());
    }
    void OnLeaderboardUpdate(UpdatePlayerStatisticsResult result)
    {
        Debug.LogError("New score has been added to the leaderboard.");
    }
    public void GetLeaderboard()
    {
        var request = new GetLeaderboardRequest
        {
            StatisticName = "Hero's Fate",
            StartPosition = 0,
            MaxResultsCount = 19
        };
        PlayFabClientAPI.GetLeaderboard(request, OnLeaderboardGet, OnLeaderBoardError);
    }
    void OnLeaderboardGet(GetLeaderboardResult result)
    {
        foreach (Transform item in rowsParent)
        {
            Destroy(item.gameObject);
        }
        foreach (var item in result.Leaderboard)
        {
            GameObject newObj = Instantiate(rowPrefab, rowsParent);
            TextMeshProUGUI[] texts = newObj.GetComponentsInChildren<TextMeshProUGUI>();
            texts[0].text = (item.Position + 1).ToString();
            texts[1].text = item.DisplayName;
            texts[2].text = item.StatValue.ToString();
        }
    }
    public void Refresh()
    {
        leaderBoardPannel.SetActive(setActive);
        setActive = !setActive;
    }
    public void OnLogOut()
    {
        SceneManager.LoadScene("ConnectingScene");
        PhotonNetwork.Disconnect();
        FindObjectOfType<AudioManager>().Play("Button_Pressed_Sound");
        FindObjectOfType<AudioManager>().StopPlaying("Battle_Sound");
        FindObjectOfType<AudioManager>().Play("MainMenu_Sound");
        Debug.LogError("Music stopped.");
    }
}
